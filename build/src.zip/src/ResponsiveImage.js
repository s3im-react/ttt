import React from 'react';
import PropTypes from 'prop-types';

import './ResponsiveImage.css';

const ResponsiveImage = ({src, alt}) => <img src={src} alt={alt} className={'ResponsiveImage'} />;

ResponsiveImage.propTypes = {
    src: PropTypes.string.isRequired,
    alt: PropTypes.string.isRequired,
};

export default ResponsiveImage;