import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {Card, CardHeader, CardText, CardTitle} from 'material-ui';
import ResponsiveImage from './ResponsiveImage';

import './Thread.css';

export default class Thread extends Component {
    static propTypes = {
        thread: PropTypes.shape({
            title:    PropTypes.string.isRequired,
            url:      PropTypes.string.isRequired,
            selftext: PropTypes.string.isRequired,
            preview:  PropTypes.shape({
                images: PropTypes.arrayOf(
                    PropTypes.shape({
                        source: PropTypes.shape({url: PropTypes.string.isRequired}),
                    }),
                ).isRequired,
            }),
        }).isRequired,
    };

    state = {expanded: false};

    get image() {
        if (!this.props.thread.preview) {
            return null;
        }

        const {preview} = this.props.thread;
        if (!preview.images && preview.images[0]) {
            return null;
        }

        const [image] = preview.images;

        return image.source.url;
    }

    render() {
        return (
            <Card className="Thread" expanded={this.state.expanded} expandable={true} style={{margin: '1em'}}>
                <CardHeader
                    title={this.props.thread.title}
                    avatar={this.image}
                    actAsExpander={true}
                    showExpandableButton={true}
                />
                <CardTitle>{this.props.thread.title}</CardTitle>
                <CardText>
                    {this.props.thread.selftext}
                </CardText>
            </Card>
        );
    }
}