import React, {Component} from 'react';
import PropTypes from 'prop-types';
import Thread from './Thread';

export default class Subreddit extends Component {
    static propTypes = {
        subreddit: PropTypes.string.isRequired,
    };

    state = {
        threads: []
    };

    async componentWillMount() {
        await this.fetchData(this.props.subreddit);
    }

    async componentWillReceiveProps(nextProps) {
        if (nextProps.subreddit !== this.props.subreddit) {
            await this.fetchData(nextProps.subreddit);
        }
    }

    async fetchData(subreddit) {
        const response = await fetch('https://api.reddit.com/r/' + subreddit);
        const json     = await response.json();

        this.setState({threads: json.data.children});
    }

    render() {
        return (
            <div>
                <h2>/r/{this.props.subreddit}</h2>
                <div>
                    {this.state.threads.map(thread => (
                        <Thread key={thread.data.id} thread={thread.data} />
                    ))}
                </div>
            </div>
        );
    }
}