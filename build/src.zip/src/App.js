import React, {Component} from 'react';
import {MuiThemeProvider} from 'material-ui';
import './App.css';
import Subreddit from './Subreddit';

class App extends Component {
    static availableSubreddits = [
        'reactjs',
        'angular'
    ];

    state = {
        subreddit: 'reactjs',
    };

    render() {
        return (
            <MuiThemeProvider>
                <div className="App">
                    <select value={this.state.subreddit} onChange={(e) => this.setState({subreddit: e.target.value})}>
                        {App.availableSubreddits.map(subreddit => (
                            <option key={'option-' + subreddit} value={subreddit}>{subreddit}</option>
                        ))}
                    </select>
                    <Subreddit subreddit={this.state.subreddit} />
                </div>
            </MuiThemeProvider>
        );
    }
}

export default App;
